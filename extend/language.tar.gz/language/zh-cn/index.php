<?php
//buyOrderOutOrInto挂买单poe
//钱包
$_['profile']=array(
    "qbzdbnwk"=>'钱包地址不能为空',
    "zfmmbnwk"=>"支付密码不能为空",
    "aqmbnwk"=>'安全码不能为空',
    "bccc"=>"保存成功",
    "bcsb"=>'保存失败',
);

//支付密码
$_['paypassword'] = array(
    'xzfmmbnwk'=>"新支付密码不能为空",
    'qrzfmmbnwk'=>"确认支付密码不能为空",
    'zfmmbnwk'=>"支付密码不能为空",
    'zfmmbzq'=>"支付密码不正确",
    'lczfmmbyz'=>"两次支付密码不一致",
    'yzfmmhxzfmmbnyy'=>"原支付密码和新支付密码不能为一样",
    'zfmmxgcg'=>"支付密码修改成功",
    'zfmmxgsb'=>"支付密码修改失败",
);
//登录密码
$_['password'] = array(
    'dlmmbnwk'=>"登录密码不能为空",
    'xmmbnwk'=>"新密码不能为空",
    'qrxmmbnwk'=>"确认新密码不能为空",
    'lcddmmbyz'=>"两次登录密码不一致",
    'dlmmywqsr'=>"登录密码有误，请重新输入",
    'ymmhxmmbnyyy'=>"原密码和新密码不能为一样",
    'mmxgcc'=>"密码修改成功",
    'mmxgsb'=>"密码修改失败",
);
//反馈信息不能为空
$_['complaint'] = array(
    'fkxxbnwk'=>"反馈信息不能为空",
    'fkcc'=>"反馈成功",
    'fksb'=>"反馈失败",
);

//pos购买
$_['scoreExchange'] = array(
    'slbnwk'=>"数量不能为空",
    'slbxdy0'=>"数量必须大于0",
    'csyw'=>"参数有误",
    'gmslbxz'=>"购买数量必须在",
    'qj'=>"区间",
    'slbnwk'=>"nac数量不足",
    'gmsls'=>"购买数量必须是",
    'bs'=>"倍数",
    'slbz'=>"nac数量不足",
    'gmcg'=>"购买成功",
    'gmsb'=>"购买失败",
    'ffcz'=>"非法操作",
);
//推荐挖矿算力(挖矿)
$_['tjcalculationWk'] = array(
    'cczwx'=>"此操作无效",
    'wkcg'=>"pos挖矿成功",
    'wksb'=>"pos挖矿失败",
);






