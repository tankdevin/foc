<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'价格不能为空',
    "jyslbnwk"=>'交易数量不能为空',
    "jgyw"=>'价格有误',
    "jyslyy"=>'交易数量有误',
    "slbzxy"=>'usdt数量不足，需要',
    "g"=>'个USDT',
    "mrcgddpp"=>'买入成功，等待匹配',
    "mrsb"=>'买入失败',
    "nacslbzxy"=>'nac数量不足，需要',
    "gnac"=>'个nac',
    "mcccddpp"=>'卖出成功，等待匹配',
    "mcsb"=>'卖出失败',
);

$_['revokeorder']=array(
    "ddbnwk"=>'订单ID不能为空',
    "gmddwx"=>'该卖单订单无效',
    "cxcg"=>'撤销成功',
    "cxsb"=>'撤销失败',
    "gmdddwx"=>'该买单订单无效',
    "cxcg"=>'撤销成功',
    "cxsb"=>'撤销失败',
);







