<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
        "mrslbuwk"=>'买入数量不能为空',
        "zfmmbnwk"=>"支付密码不能为空",
        "mcslyw"=>'卖出数量有误',
        "pdjew"=>"排单金额为",
        "dbs"=>'的倍数',
        "nacslbz"=>'nac数量不足，需要',
        "ge"=>'个',
        "qwsddxx"=>'请完善打款信息',
        "gmcg"=>'购买成功，等待匹配',
        "gmsb"=>'购买失败',

    ),
);

//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"待匹配中，无法查看订单详情",
    'wzddydppdd'=>"未找到对应的匹配订单",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"未找到对应的记录",
    'tpyysc'=>"图片已经上传",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"订单号不能为空",
    'scdkjtbnwk'=>"上传打款截图不能为空",
    'qrfkcg'=>"确认付款成功",
    'qrfksb'=>"确认付款失败",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"未找到对应的匹配订单",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"未找到对应的匹配订单",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"无效订单",
    'qrcg'=>"确认成功",
    'qrsb'=>"确认失败",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"订单ID不能为空",
    'qxcg'=>"取消成功",
    'qxsb'=>"取消失败",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"此操作无效",
    'wkcg'=>"poe挖矿成功",
    'wksb'=>"poe挖矿失败",
);















