<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['login']=array(
    "zhbnwk"=>'账号不能为空',
    "mmbnwk"=>"密码不能为空",
    "zhbcz"=>'账号不存在',
    "zhbczqlxgly"=>"账号被冻结,请联系管理员",
    "mmcw"=>'密码错误',
    "dlcg"=>'登录成功',
    "dlsb"=>'登录失败',
);

//注册
$_['register'] = array(
    'qsryx'=>"请输入邮箱",
    'yxgsbzq'=>"邮箱格式不正确",
    'yxyjcz'=>"邮箱已经存在",
    'qsrnc'=>"请输入昵称",
    'qsrmm'=>"请输入密码",
    'qsryym'=>"请输入邀请码",
    'ncyczqgh'=>"昵称已存在，请更换",
    'tjrbcz'=>"推荐人不存在",
    'zccc'=>"注册成功",
    'zcsb'=>"注册失败",

);






