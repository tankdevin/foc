<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'上传失败',
);


$_['saveBase64Image']=array(
    "scsb"=>'不允许上传的文件类型',
    "scsb"=>'保存成功',
    "scsb"=>'图片保存失败',
    "scsb"=>'base64图片格式有误',
);




