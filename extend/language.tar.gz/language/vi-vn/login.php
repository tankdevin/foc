<?php
//buyOrderOutOrInto挂买单poe
$_['login']=array(
    "zhbnwk"=>'Số tài khoản không thể rỗng',
    "mmbnwk"=>"Mật khẩu không thể rỗng",
    "zhbcz"=>'Tài khoản không tồn tại',
    "zhbczqlxgly"=>"Tài khoản đóng băng, liên lạc quản trị",
    "mmcw"=>'Lỗi mật khẩu',
    "dlcg"=>'Thành công Đăng nhập',
    "dlsb"=>'Lỗi đăng nhập',
);

//
//注册
$_['register'] = array(
    'qsryx'=>"Hãy nhập địa chỉ email",
    'yxgsbzq'=>"Hộp thư không đúng",
    'yxyjcz'=>"Hộp thư đã có",
    'qsrnc'=>"Hãy nhập nickname của em",
    'qsrmm'=>"Nhập mật khẩu đi.",
    'qsryym'=>"Hãy nhập mã thư mời.",
    'ncyczqgh'=>"Biệt danh đã có, xin hãy thay đổi nó",
    'tjrbcz'=>"Lời khuyên không tồn tại",
    'zccc'=>"đã đăng nhập thành công",
    'zcsb'=>"Lỗi đăng nhập",

);








