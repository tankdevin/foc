<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['uploadPersonalimage']=array(
    "grtxsccc"=>'Ảnh cá nhân được tải lên',
    "grtxscsb"=>'Lỗi tải ảnh cá nhân',
);







