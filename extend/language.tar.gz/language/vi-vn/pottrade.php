<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
       "mrslbuwk"=>'Số lượng mua không thể rỗng',
       "zfmmbnwk"=>"Mật khẩu thanh toán không thể rỗng",
       "mcslyw"=>'Bán nhầm số',
       "pdjew"=>"Số tiền là",
       "dbs"=>'Đa phần',
       "nacslbz"=>'Số lượng không đủ, nhu cầu',
       "ge"=>'cá nhân',
       "qwsddxx"=>'Vui lòng cải thiện thông tin thanh toán',
       "gmcg"=>'Giá thành công, chờ kết quả khớp',
       "gmsb"=>'Lỗi mua',

    ),
);

//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"Không thể xem chi tiết mệnh lệnh",
    'wzddydppdd'=>"Không tìm thấy lệnh khớp",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"Không tìm thấy ghi chép tương ứng",
    'tpyysc'=>"Ảnh đã được tải lên",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"Số lệnh không thể rỗng",
    'scdkjtbnwk'=>"Tải màn hình thanh tra lên không thể rỗng",
    'qrfkcg'=>"Xác nhận thanh toán",
    'qrfksb'=>"Mã thanh toán lỗi",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"Không tìm thấy lệnh khớp",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"Không tìm thấy lệnh khớp",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"Thứ tự sai",
    'qrcg'=>"Xác nhận thành công",
    'qrsb'=>"Xác nhận lỗi",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"Mã số lệnh không thể rỗng",
    'qxcg'=>"Xoá thành công",
    'qxsb'=>"Lỗi hủy bỏ",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"Hoạt động này không hợp lệ",
    'wkcg'=>"Thành công khai mỏ Poe",
    'wksb'=>"Lỗi khai thác Poe",
);






