<?php
//buyOrderOutOrInto挂买单poe
//钱包
$_['profile']=array(
    "qbzdbnwk"=>'Ví không thể rỗng',
    "zfmmbnwk"=>"Mật khẩu thanh toán không thể rỗng",
    "aqmbnwk"=>'Mật mã không thể rỗng',
    "bccc"=>"Lưu thành công",
    "bcsb"=>'Lỗi lưu',
);

//支付密码
$_['paypassword'] = array(
    'xzfmmbnwk'=>"Không thể bỏ mật khẩu thanh toán mới",
    'qrzfmmbnwk'=>"Xác nhận mật khẩu thanh toán không thể rỗng",
    'zfmmbnwk'=>"Mật khẩu thanh toán không thể rỗng",
    'zfmmbzq'=>"Mật khẩu thanh toán sai",
    'lczfmmbyz'=>"Hai mật khẩu thanh toán không khớp với nhau.",
    'yzfmmhxzfmmbnyy'=>"Mật khẩu thanh toán gốc và mật khẩu thanh toán mới không thể giống nhau.",
    'zfmmxgcg'=>"Thanh toán Comment",
    'zfmmxgsb'=>"Lỗi sửa đổi mật khẩu

",
);
//登录密码
$_['password'] = array(
    'dlmmbnwk'=>"Không thể rỗng mật khẩu đăng nhập",
    'xmmbnwk'=>"Không thể bỏ mật khẩu mới",
    'qrxmmbnwk'=>"Xác nhận mật khẩu mới không thể rỗng",
    'lcddmmbyz'=>"Hai mật khẩu đăng nhập không có mâu thuẫn",
    'dlmmywqsr'=>"Lỗi đăng nhập mật khẩu, xin nhập lại",
    'ymmhxmmbnyyy'=>"Mật khẩu gốc và mật khẩu mới không thể giống nhau.",
    'zfmmxgcc'=>"Thanh toán Comment",
    'zfmmxgsb'=>"Lỗi sửa đổi mật khẩu",
);
//反馈信息不能为空
$_['complaint'] = array(
    'fkxxbnwk'=>"Thông tin nạp tin không thể rỗng",
    'fkcc'=>"Hậu quả",
    'fksb'=>"Phản hồi lỗi",
);

//pos购买
$_['scoreExchange'] = array(
    'slbnwk'=>"Số lượng không thể rỗng",
    'slbxdy0'=>"Số lượng phải lớn hơn 0",
     'csyw'=>"tham số lỗi",
    'gmslbxz'=>"Số lượng mua phải có trong",
    'qj'=>"Phần",
    'slbnwk'=>"Thiếu sự hợp pháp",
    'gmsls'=>"Số lượng mua phải là",
    'bs'=>"đa",
    'slbz'=>"Thiếu sự hợp pháp",
    'gmcg'=>"Giá được mua",
    'gmsb'=>"Lỗi mua",
    'ffcz'=>"Thao tác bất hợp pháp",
);
//推荐挖矿算力(挖矿)
$_['tjcalculationWk'] = array(
    'cczwx'=>"Hoạt động này không hợp lệ",
    'wkcg'=>"Thành công khai thác",
    'wksb'=>"Lỗi khai thác POS",
);




