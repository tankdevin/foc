<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'Giá trị không thể rỗng',
    "jyslbnwk"=>'Chất lượng giao dịch không thể rỗng',
    "jgyw"=>'Cái giá không đúng.',
    "jyslyy"=>'Không đúng số giao dịch',
    "slbzxy"=>'Không đủ, cần',
    "g"=>'cá nhân',
    "mrcgddpp"=>'Đi mua thành công, chờ trận đấu',
    "mrsb"=>'Lỗi mua',
    "nacslbzxy"=>'Số lượng không đủ, nhu cầu',
    "gnac"=>'Comment',
    "mcccddpp"=>'Bán thành công, chờ trận đấu',
    "mcsb"=>'Bán thất bại',
);

$_['revokeorder']=array(
    "ddbnwk"=>'Mã số lệnh không thể rỗng',
    "gmddwx"=>'Đơn hàng không hợp lệ',
    "cxcg"=>'Kết thúc',
    "cxsb"=>'Lỗi hủy bỏ',
    "gmdddwx"=>'Thứ tự không hợp lệ',
    "cxcg"=>'Kết thúc',
    "cxsb"=>'Lỗi hủy bỏ',
);







