<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'Lỗi tải lên',
);

$_['saveBase64Image']=array(
    "scsb"=>'Không thể tải lên kiểu tập tin',
    "scsb"=>'Lưu thành công',
    "scsb"=>'Lỗi lưu ảnh',
    "scsb"=>'base64Sai định dạng ảnh',
);





