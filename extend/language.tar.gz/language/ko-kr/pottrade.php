<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
       "mrslbuwk"=>'매입 수량 이 공백 일 수 없다',
       "zfmmbnwk"=>"지급 비밀 번 호 는 비 어 있 으 면 안 됩 니 다.",
       "mcslyw"=>'판매 수량 에 착오 가 있다.',
       "pdjew"=>"배정 금액 은",
       "dbs"=>'의 배수',
       "nacslbz"=>'nac 수량 부족, 필요',
       "ge"=>'개',
       "qwsddxx"=>'입금 정 보 를 완벽 하 게 해 주세요.',
       "gmcg"=>'구 매 성공, 매 칭 대기',
       "gmsb"=>'구 매 실패',

    ),
);

//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"매 칭 대기 중, 주문서 상세 보기 불가",
    'wzddydppdd'=>"해당 하 는 주문 서 를 찾 을 수 없습니다",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"해당 하 는 주문 서 를 찾 을 수 없습니다",
    'tpyysc'=>"사진 이 업로드 되 었 습 니 다.",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"주문 번호 가 비 어 있 으 면 안 됩 니 다.",
    'scdkjtbnwk'=>"입금 캡 처 올 려 주시 면 안 돼 요.",
    'qrfkcg'=>"지불 확인 성공",
    'qrfksb'=>"지불 확인 실패",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"해당 하 는 주문 서 를 찾 을 수 없습니다",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"해당 하 는 주문 서 를 찾 을 수 없습니다",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"무효 주문",
    'qrcg'=>"확인 성공",
    'qrsb'=>"확인 실패",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"주문 ID 공백 일 수 없습니다",
    'qxcg'=>"취소 성공",
    'qxsb'=>"취소 실패",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"이 조작 은 무효 이다",
    'wkcg'=>"poe 채굴 성공",
    'wksb'=>"poe 채굴 실패",
);






