<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'업로드 실패',
);

$_['saveBase64Image']=array(
    "scsb"=>'업로드 불가 파일 형식',
    "scsb"=>'저장 완료',
    "scsb"=>'그림 저장 실패',
    "scsb"=>'base64이미지 양식 에 오류 가 있다.',
);





