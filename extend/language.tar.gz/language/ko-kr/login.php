<?php
//buyOrderOutOrInto挂买单poe
$_['login']=array(
    "zhbnwk"=>'로그 인 실패',
    "mmbnwk"=>"비밀 번 호 는 비어 있 으 면 안 됩 니 다.",
    "zhbcz"=>'계 정 없 음',
    "zhbczqlxgly"=>"계 정 이 동결 되 었 습 니 다. 관리자 에 게 연락 하 세 요",
    "mmcw"=>'암호 오류',
    "dlcg"=>'로그 인 성공',
    "dlsb"=>'로그 인 실패',
);

//注册
$_['register'] = array(
    'qsryx'=>"메 일 박스 를 입력 하 세 요.",
    'yxgsbzq'=>"메 일주 소 형식 이 잘못 되 었 습 니 다.",
    'yxyjcz'=>"메 일 박스 가 이미 존재 합 니 다.",
    'qsrnc'=>"닉네임 을 입력 하 세 요",
    'qsrmm'=>"비밀 번 호 를 입력 하 세 요.",
    'qsryym'=>"요청 코드 를 입력 하 세 요",
    'ncyczqgh'=>"닉네임 이 이미 존재 합 니 다. 변경 하 세 요",
    'tjrbcz'=>"추천인 은 존재 하지 않 습 니 다.",
    'zccc'=>"등록 성공",
    'zcsb'=>"등록 실패",

);






