<?php
//buyOrderOutOrInto挂买单poe
//钱包
$_['profile']=array(
    "qbzdbnwk"=>'지갑 주 소 는 비어 있 으 면 안 됩 니 다.',
    "zfmmbnwk"=>"지급 비밀 번 호 는 비 어 있 으 면 안 됩 니 다.",
    "aqmbnwk"=>'안전 코드 가 비어 있 으 면 안 됩 니 다.',
    "bccc"=>"저장 완료",
    "bcsb"=>'저장 실패',
);

//支付密码
$_['paypassword'] = array(
    'xzfmmbnwk'=>"새 지불 비밀 번 호 는 비어 있 으 면 안 됩 니 다.",
    'qrzfmmbnwk'=>"지급 비밀 번 호 를 확인 하면 비 어 있 으 면 안 됩 니 다.",
    'zfmmbnwk'=>"지급 비밀 번 호 는 비 어 있 으 면 안 됩 니 다.",
    'zfmmbzq'=>"지불 비밀번호 가 정확 하지 않다",
    'lczfmmbyz'=>"두 번 째 결제 비밀번호 가 일치 하지 않 습 니 다.",
    'yzfmmhxzfmmbnyy'=>"원래 지불 비밀 번 호 는 새로 지불 한 비밀번호 와 같 을 수 없다.",
    'zfmmxgcg'=>"지급 비밀번호 변경 성공",
    'zfmmxgsb'=>"지급 비밀번호 변경 실패",
);
//登录密码
$_['password'] = array(
    'dlmmbnwk'=>"로그 인 비밀번호 가 비어 있 으 면 안 됩 니 다",
    'xmmbnwk'=>"새 암 호 는 비어 있 으 면 안 됩 니 다.",
    'qrxmmbnwk'=>"새 비밀번호 가 비어 있 으 면 안 됩 니 다",
    'lcddmmbyz'=>"두 번 의 로그 인 비밀번호 가 일치 하지 않 습 니 다.",
    'dlmmywqsr'=>"로그 인 비밀번호 가 잘못 되 었 습 니 다. 다시 입력 하 세 요.",
    'ymmhxmmbnyyy'=>"원래 비밀번호 와 새 비밀 번 호 는 같 을 수 없습니다.",
    'zfmmxgcc'=>"지급 비밀번호 변경 성공",
    'zfmmxgsb'=>"지급 비밀번호 변경 실패",
);
//反馈信息不能为空
$_['complaint'] = array(
    'fkxxbnwk'=>"피드백 정 보 는 공백 상태 가 되 어 서 는 안 된다.",
    'fkcc'=>"피드백 성공",
    'fksb'=>"피드백 실패",
);

//pos购买
$_['scoreExchange'] = array(
    'slbnwk'=>"수량 이 공백 일 수 없습니다",
    'slbxdy0'=>"수량 이 0 이상 이 어야 합 니 다.",
    'csyw'=>"인자 에 오류 가 있다.",
    'gmslbxz'=>"구 매 수량 은",
    'csyw'=>"인자 에 오류 가 있다.",
    'qj'=>"구간.",
    'slbnwk'=>"nac 수량 부족",
    'gmsls'=>"구 매 수량 은",
    'bs'=>"배수.",
    'slbz'=>"nac 수량 부족",
    'gmcg'=>"구 매 성공",
    'gmsb'=>"구 매 실패",
    'ffcz'=>"불법 조작",
);
//推荐挖矿算力(挖矿)
$_['tjcalculationWk'] = array(
    'cczwx'=>"이 조작 은 무효 이다",
    'wkcg'=>"pos 채굴 성공",
    'wksb'=>"pos 채굴 실패",
);





