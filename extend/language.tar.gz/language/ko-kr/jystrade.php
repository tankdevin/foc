<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'가격 이 비 어 있 으 면 안 됩 니 다.',
    "jyslbnwk"=>'거래 수량 공백 일 수 없습니다',
    "jgyw"=>'가격 에 착오 가 있다.',
    "jyslyy"=>'거래 수량 에 착오 가 있다.',
    "slbzxy"=>'usdt 수량 부족, 필요',
    "g"=>'개.',
    "mrcgddpp"=>'구입 성공, 매 칭 대기',
    "mrsb"=>'매입 실패',
    "nacslbzxy"=>'nac 수량 부족, 필요',
    "gnac"=>'개 nac',
    "mcccddpp"=>'판매 성공, 매 칭 대기',
    "mcsb"=>'매출 실패',
);

$_['revokeorder']=array(
    "ddbnwk"=>'주문 ID 공백 일 수 없습니다',
    "gmddwx"=>'이 매도 주문서 는 무효 이다',
    "cxcg"=>'취소 성공',
    "cxsb"=>'취소 실패',
    "gmdddwx"=>'이 계산 은 주문서 가 무효 이다',
    "cxcg"=>'취소 성공',
    "cxsb"=>'취소 실패',
);







