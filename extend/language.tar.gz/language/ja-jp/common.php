<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'フィードバック失敗',
);

$_['saveBase64Image']=array(
    "scsb"=>'アップロードが許可されていないファイルタイプ',
    "scsb"=>'保存に成功しました',
    "scsb"=>'画像の保存に失敗しました',
    "scsb"=>'base64画像のフォーマットが間違っています',
);





