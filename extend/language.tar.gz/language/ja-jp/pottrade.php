<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
        "mrslbuwk"=>'購入数量は空いてはいけません。',
        "zfmmbnwk"=>"パスワードの支払いは空ではできません。",
        "mcslyw"=>'販売数量が間違っています',
        "pdjew"=>"インボイスの金額は",
        "dbs"=>'の倍数',
        "nacslbz"=>'nac数量が足りないので、必要です。',
        "ge"=>'個',
        "qwsddxx"=>'入金情報を完備してください。',
        "gmcg"=>'購入成功、マッチングを待つ',
        "gmsb"=>'購入に失敗しました',

    ),
);

//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"マッチング中に注文の詳細を確認できませんでした。",
    'wzddydppdd'=>"対応するマッチした注文が見つかりませんでした。",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"対応するレコードが見つかりませんでした。",
    'tpyysc'=>"画像をアップロードしました",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"注文番号は空ではいけません。",
    'scdkjtbnwk'=>"アップロードのショートカットは空です。",
    'qrfkcg'=>"支払いの確認",
    'qrfksb'=>"支払い確認失敗",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"対応するマッチした注文が見つかりませんでした。",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"対応するマッチした注文が見つかりませんでした",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"無効な注文",
    'qrcg'=>"成功を確認します",
    'qrsb'=>"確認失敗",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"注文IDは空にできません",
    'qxcg'=>"キャンセル成功",
    'qxsb'=>"キャンセルに失敗しました",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"この操作は無効です",
    'wkcg'=>"この操作は無効です",
    'wksb'=>"poe掘削成功",
);






