<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'価格は空です',
    "jyslbnwk"=>'取引の数量は空ではいけません。',
    "jgyw"=>'価格が間違っています',
    "jyslyy"=>'取引の数量が間違っています',
    "slbzxy"=>'usdt数量が足りないので、必要です。',
    "g"=>'個',
    "mrcgddpp"=>'購入成功、マッチング待ち',
    "mrsb"=>'買い入れに失敗しました',
    "nacslbzxy"=>'nac数量が足りないので、必要です。',
    "gnac"=>'個のnac',
    "mcccddpp"=>'販売成功、マッチ待ち',
    "mcsb"=>'販売に失敗しました',
);

$_['revokeorder']=array(
    "ddbnwk"=>'注文IDは空にできません',
    "gmddwx"=>'この売り注文は無効です。',
    "cxcg"=>'キャンセル成功',
    "cxsb"=>'キャンセルに失敗しました',
    "gmdddwx"=>'この注文は無効です。',
    "cxcg"=>'キャンセル成功',
    "cxsb"=>'キャンセルに失敗しました',
);







