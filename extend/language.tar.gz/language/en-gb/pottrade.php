<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
        "mrslbuwk"=>'Purchase quantity cannot be empty',
        "zfmmbnwk"=>"Payment password cannot be empty",
        "mcslyw"=>'Wrong quantity sold',
        "pdjew"=>"The amount is",
        "dbs"=>'Multiple of',
        "nacslbz"=>'nac Insufficient quantity, need',
        "ge"=>'individual',
        "qwsddxx"=>'Please improve the payment information',
        "gmcg"=>'Purchase successful, waiting for matching',
        "gmsb"=>'Purchase failed',

    ),
);
//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"To be matched, unable to view order details",
    'wzddydppdd'=>"No matching order was found",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"No corresponding record was found",
    'tpyysc'=>"The picture has been uploaded",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"Order number cannot be empty",
    'scdkjtbnwk'=>"Upload payment screenshot cannot be empty",
    'qrfkcg'=>"Upload payment screenshot cannot be empty",
    'qrfksb'=>"Payment confirmation failed",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"No matching order was found",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"No matching order was found",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"Invalid order",
    'qrcg'=>"Confirm success",
    'qrsb'=>"Confirmation failed",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"Order ID cannot be empty",
    'qxcg'=>"Cancelled successfully",
    'qxsb'=>"Cancellation failed",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"This operation is not valid",
    'wkcg'=>"Successful mining of Poe",
    'wksb'=>"Poe mining failure",
);






