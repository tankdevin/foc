<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'Price cannot be empty',
    "jyslbnwk"=>'Transaction quantity cannot be empty',
    "jgyw"=>'The price is wrong',
    "jyslyy"=>'Wrong number of transactions',
    "slbzxy"=>'Not enough usdt, need',
    "g"=>'individual',
    "mrcgddpp"=>'Buy successfully, waiting for match',
    "mrsb"=>'Buy failure',
    "nacslbzxy"=>'Insufficient NAC quantity, need',
    "gnac"=>'NACs',
    "mcccddpp"=>'Sell successfully, waiting for match',
    "mcsb"=>'Sell failure',
);

$_['revokeorder']=array(
    "ddbnwk"=>'Order ID cannot be empty',
    "gmddwx"=>'The sales order is invalid',
    "cxcg"=>'Revocation successful',
    "cxsb"=>'Revocation failed',
    "gmdddwx"=>'The order is invalid',
    "cxcg"=>'Revocation successful',
    "cxsb"=>'Revocation failed',
);







