<?php
//buyOrderOutOrInto挂买单poe
//钱包
$_['profile']=array(
    "qbzdbnwk"=>'Wallet address cannot be empty',
    "zfmmbnwk"=>"Payment password cannot be empty",
    "aqmbnwk"=>'Security code cannot be empty',
    "bccc"=>"Saved successfully",
    "bcsb"=>'Save failed',
);

//支付密码
$_['paypassword'] = array(
    'xzfmmbnwk'=>"New payment password cannot be empty",
    'qrzfmmbnwk'=>"Confirm payment password cannot be empty",
    'zfmmbnwk'=>"Payment password cannot be empty",
    'zfmmbzq'=>"Incorrect payment password",
    'lczfmmbyz'=>"The two payment passwords are inconsistent",
    'yzfmmhxzfmmbnyy'=>"The original payment password and the new payment password cannot be the same",
    'zfmmxgcg'=>"Payment password modified successfully",
    'zfmmxgsb'=>"Payment password modification failed",
);
//登录密码
$_['password'] = array(
    'dlmmbnwk'=>"Login password cannot be empty",
    'xmmbnwk'=>"New password cannot be empty",
    'qrxmmbnwk'=>"Confirm new password cannot be empty",
    'lcddmmbyz'=>"The two login passwords are inconsistent",
    'dlmmywqsr'=>"Login password error, please re-enter",
    'ymmhxmmbnyyy'=>"The original password and the new password cannot be the same",
    'zfmmxgcc'=>"Payment password modified successfully",
    'zfmmxgsb'=>"Payment password modification failed",
);
//反馈信息不能为空
$_['complaint'] = array(
    'fkxxbnwk'=>"Feedback information cannot be empty",
    'fkcc'=>"Feedback success",
    'fksb'=>"Feedback failed",
);

//pos购买
$_['scoreExchange'] = array(
    'slbnwk'=>"Quantity cannot be empty",
    'slbxdy0'=>"Quantity must be greater than 0",
    'csyw'=>"Parameter error",
    'gmslbxz'=>"Purchase quantity must be in",
    'qj'=>"section",
    'slbnwk'=>"Lack of NAC",
    'gmsls'=>"Purchase quantity must be",
    'bs'=>"multiple",
    'slbz'=>"Lack of NAC",
    'gmcg'=>"Purchase successful",
    'gmsb'=>"Purchase failed",
    'ffcz'=>"Illegal operation",
);
//推荐挖矿算力(挖矿)
$_['tjcalculationWk'] = array(
    'cczwx'=>"This operation is not valid",
    'wkcg'=>"POS mining success",
    'wksb'=>"POS mining failure",
);




