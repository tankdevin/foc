<?php
//buyOrderOutOrInto挂买单poe
$_['login']=array(
    "zhbnwk"=>'Account number cannot be empty',
    "mmbnwk"=>"Password cannot be empty",
    "zhbcz"=>'Account does not exist',
    "zhbczqlxgly"=>"Account is frozen, please contact administrator",
    "mmcw"=>'Password error',
    "dlcg"=>'Login successful',
    "dlsb"=>'Login failed',
);

//注册
$_['register'] = array(
    'qsryx'=>"Please enter email address",
    'yxgsbzq'=>"The mailbox format is incorrect",
    'yxyjcz'=>"The mailbox already exists",
    'qsrnc'=>"Please enter your nickname",
    'qsrmm'=>"Please input a password",
    'qsryym'=>"Please enter the invitation code",
    'ncyczqgh'=>"The nickname already exists, please change it",
    'tjrbcz'=>"The recommender does not exist",
    'zccc'=>"login was successful",
    'zcsb'=>"login has failed",

);






