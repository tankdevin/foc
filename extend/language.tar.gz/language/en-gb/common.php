<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'Upload failed',
);

$_['saveBase64Image']=array(
    "scsb"=>'File type not allowed to upload',
    "scsb"=>'Saved successfully',
    "scsb"=>'Failed to save picture',
    "scsb"=>'base64Wrong image format',
);





