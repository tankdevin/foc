<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['fileImage']=array(
    "scsb"=>'上傳失敗',
);
$_['saveBase64Image']=array(
    "scsb"=>'不允許上傳的檔案類型',
    "scsb"=>'保存成功',
    "scsb"=>'圖片保存失敗',
    "scsb"=>'base64圖片格式有誤',
);






