<?php
//buyOrderOutOrInto挂买单poe
$_['buyOrderOutOrInto']=array(
    "data"=>array(
       "mrslbuwk"=>'買入數量不能為空',
       "zfmmbnwk"=>"支付密碼不能為空",
       "mcslyw"=>'賣出數量有誤',
       "pdjew"=>"排單金額為",
       "dbs"=>'的倍數',
       "nacslbz"=>'nac數量不足，需要',
       "ge"=>'個',
       "qwsddxx"=>'請完善打款信息',
       "gmcg"=>'購買成功，等待匹配',
       "gmsb"=>'購買失敗',

    ),
);

//点击买单，出现买单和匹配单
$_['buydetail'] = array(
    'dppzwfckddxq'=>"待匹配中，無法查看訂單詳情",
    'wzddydppdd'=>"未找到對應的匹配訂單",
);

//点击买单，出现买单和匹配单
$_['buypayone'] = array(
    'wzddydjl'=>"未找到對應的記錄",
    'tpyysc'=>"圖片已經上傳",
);

//确认打款
$_['upPayimg'] = array(
    'ddbnwk'=>"訂單號不能為空",
    'scdkjtbnwk'=>"上傳打款截圖不能為空",
    'qrfkcg'=>"確認付款成功",
    'qrfksb'=>"確認付款失敗",
);
//确认打款
$_['selldetail'] = array(
    'wzddydppdd'=>"未找到對應的匹配訂單",
);
//出售一条匹配详情
$_['sellmatchone'] = array(
    'wzddydppdd'=>"未找到對應的匹配訂單",
);
//确认收款
$_['sellok'] = array(
    'wxdd'=>"無效訂單",
    'qrcg'=>"確認成功",
    'qrsb'=>"確認失敗",
);
//取消订单
$_['cancelC2cOrder'] = array(
    'ddidbnwk'=>"訂單ID不能為空",
    'qxcg'=>"取消成功",
    'qxsb'=>"取消失敗",
);
//见点挖矿算力(挖矿)
$_['jdalculationWk'] = array(
    'cczwx'=>"此操作無效",
    'wkcg'=>"poe挖礦成功",
    'wksb'=>"poe挖礦失敗",
);










