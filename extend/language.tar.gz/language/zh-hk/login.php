<?php
//buyOrderOutOrInto挂买单poe
$_['login']=array(
    "zhbnwk"=>'帳號不能為空',
    "mmbnwk"=>"密碼不能為空",
    "zhbcz"=>'帳號不存在',
    "zhbczqlxgly"=>"帳號被凍結，請聯系管理員",
    "mmcw"=>'密碼錯誤',
    "dlcg"=>'登入成功',
    "dlsb"=>'登入失敗',
);

//注册
$_['register'] = array(
    'qsryx'=>"請輸入郵箱",
    'yxgsbzq'=>"郵箱格式不正確",
    'yxyjcz'=>"郵箱已經存在",
    'qsrnc'=>"請輸入昵稱",
    'qsrmm'=>"請輸入密碼",
    'qsryym'=>"請輸入邀請碼",
    'ncyczqgh'=>"昵稱已存在，請更換",
    'tjrbcz'=>"推薦人不存在",
    'zccc'=>"注册成功",
    'zcsb'=>"注册失敗",

);






