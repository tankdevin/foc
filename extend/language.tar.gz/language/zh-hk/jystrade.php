<?php
//buyOrderOutOrInto挂买单poe
//登录
$_['buyOrderOutOrInto']=array(
    "jgbnwk"=>'價格不能為空',
    "jyslbnwk"=>'交易數量不能為空',
    "jgyw"=>'價格有誤',
    "jyslyy"=>'交易數量有誤',
    "slbzxy"=>'usdt數量不足，需要',
    "g"=>'個',
    "mrcgddpp"=>'買入成功，等待匹配',
    "mrsb"=>'買入失敗',
    "nacslbzxy"=>'nac數量不足，需要',
    "gnac"=>'個nac',
    "mcccddpp"=>'賣出成功，等待匹配',
    "mcsb"=>'賣出失敗',
);

$_['revokeorder']=array(
    "ddbnwk"=>'訂單ID不能為空',
    "gmddwx"=>'該賣單訂單無效',
    "cxcg"=>'撤銷成功',
    "cxsb"=>'撤銷失敗',
    "gmdddwx"=>'該買單訂單無效',
    "cxcg"=>'撤銷成功',
    "cxsb"=>'撤銷失敗',
);







