<?php
//buyOrderOutOrInto挂买单poe
//钱包
$_['profile']=array(
    "qbzdbnwk"=>'錢包地址不能為空',
    "zfmmbnwk"=>"支付密碼不能為空",
    "aqmbnwk"=>'安全碼不能為空',
    "bccc"=>"保存成功",
    "bcsb"=>'保存失敗',
);

//支付密码
$_['paypassword'] = array(
    'xzfmmbnwk'=>"新支付密碼不能為空",
    'qrzfmmbnwk'=>"確認支付密碼不能為空",
    'zfmmbnwk'=>"支付密碼不能為空",
    'zfmmbzq'=>"支付密碼不正確",
    'lczfmmbyz'=>"兩次支付密碼不一致",
    'yzfmmhxzfmmbnyy'=>"原支付密碼和新支付密碼不能為一樣",
    'zfmmxgcg'=>"支付密碼修改成功",
    'zfmmxgsb'=>"支付密碼修改失敗",
);
//登录密码
$_['password'] = array(
    'dlmmbnwk'=>"登入密碼不能為空",
    'xmmbnwk'=>"新密碼不能為空",
    'qrxmmbnwk'=>"確認新密碼不能為空",
    'lcddmmbyz'=>"兩次登入密碼不一致",
    'dlmmywqsr'=>"登入密碼有誤，請重新輸入",
    'ymmhxmmbnyyy'=>"原密碼和新密碼不能為一樣",
    'zfmmxgcc'=>"支付密碼修改成功",
    'zfmmxgsb'=>"支付密碼修改失敗",
);
//反馈信息不能为空
$_['complaint'] = array(
    'fkxxbnwk'=>"迴響資訊不能為空",
    'fkcc'=>"迴響成功",
    'fksb'=>"迴響失敗",
);

//pos购买
$_['scoreExchange'] = array(
    'slbnwk'=>"數量不能為空",
    'slbxdy0'=>"數量必須大於0",
     'csyw'=>"參數有誤",
    'gmslbxz'=>"購買數量必須在",
    'qj'=>"區間",
    'slbnwk'=>"nac數量不足",
    'gmsls'=>"購買數量必須是",
    'bs'=>"倍數",
    'slbz'=>"nac數量不足",
    'gmcg'=>"購買成功",
    'gmsb'=>"購買失敗",
    'ffcz'=>"非法操作",
);
//推荐挖矿算力(挖矿)
$_['tjcalculationWk'] = array(
    'cczwx'=>"此操作無效",
    'wkcg'=>"pos挖礦成功",
    'wksb'=>"pos挖礦失敗",
);






